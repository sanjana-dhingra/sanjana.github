function sock() {
var n=17;
var arr=[10,10,10,10,20,30,30,30,30,30,30,30,40,40,40,40,40];
arr.sort(function(a,b){ return a-b;});

var count=0;
var temp=0;
for(var i=0;i<arr.length;i++)
{
count=1;
for(var j=i+1;j<arr.length;j++)
{
if(arr[i]==arr[j])
{
count++;
}
}
if (count % 2 == 0)
{
temp++;
}
}

return temp;
}
console.log(sock())